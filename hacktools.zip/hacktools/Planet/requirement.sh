#!/bin/python
# 
#
# Name	:	IP Attack
# Code		:	python
# Sec.Code	:	8h4i
# Coder		: 	Sutariya Parixit
# Site		: 	bhai4you.blogspot.com
# github	:	github.com/Bhai4You
#
#
#	<==(__WARNING__)==>
#
# DO NOT MODIFY OR COPY WITHOUT PERMISSION !!!
#
#	<==(__WARNING__)==>
#
#
#
apt update
apt upgrade 
apt install figlet -y
apt install toilet -y
apt install nano -y
apt install ruby -y
apt install curl -y
gem install lolcat
clear
toilet -f pagga "Done..!!" | lolcat

